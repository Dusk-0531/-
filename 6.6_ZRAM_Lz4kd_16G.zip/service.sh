#!/system/bin/sh
# by Han | 情非得已c
# 请尽量使用$MODDIR获取本模块路径，即使Magisk将来更改挂载路径也依然有效
# 编写你的shell脚本，post-fs-data.sh是开机前阻塞运行的，执行完本脚本才启动开机流程和挂载模块，请不要写运行时间太久的代码，否则后果自负
MODDIR=${0%/*}

sleep 30

su -c swapoff /dev/block/zram0
su -c rmmod zram
sleep 5
su -c insmod $MODDIR/zram.ko
sleep 5
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize
#echo '8' > /sys/block/zram0/max_comp_streams
echo 'lz4kd' >/sys/block/zram0/comp_algorithm
echo '17179869184' > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1


